# RC-Car-Racing-Game

A lightweight top-down RC car racing demo (keyboard-controlled) built with HTML, CSS and JavaScript.
- Controls: Arrow keys (↑ accelerate, ↓ brake/reverse, ←/→ turn)
- Drop these files into your GitHub repo and enable GitHub Pages to publish.

Files:
- index.html
- styles.css
- script.js
- car.svg

Made for quick demo and portfolio. Good to upload to GitHub and show a working demo.
